import 'dart:convert';

import 'package:dirronlive/core/storage/json_store.dart';
import 'package:dirronlive/core/storage/storage_exception.dart';

/// Хранилище в памяти для тестов: ведёт себя как файлы (JSON-текст),
/// умеет имитировать ошибку записи.
class MemoryJsonStore implements JsonStore {
  final Map<String, String> files = {};
  bool failWrites = false;
  int writeCount = 0;

  @override
  String get location => 'память (тест)';

  @override
  Future<Map<String, Object?>?> read(String name) async {
    final text = files[name];
    if (text == null || text.trim().isEmpty) return null;
    final decoded = jsonDecode(text);
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('Ожидался JSON-объект');
    }
    return decoded;
  }

  @override
  Future<void> write(String name, Map<String, Object?> data) async {
    if (failWrites) {
      throw StorageException('Нет доступа к файлу «$name» (имитация ошибки).');
    }
    writeCount++;
    files[name] = jsonEncode(data);
  }

  @override
  Future<String?> quarantine(String name) async {
    final text = files.remove(name);
    if (text == null) return null;
    final backup = '$name.broken';
    files[backup] = text;
    return backup;
  }
}
