// Обновление с первой версии: старые файлы (без поля доставки и без
// настройки связи) открываются, ник и история сохраняются.

import 'dart:convert';

import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/features/events/event_history_repository.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/settings/settings_repository.dart';
import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/ui/screens/history_screen.dart';
import 'package:dirronlive/ui/screens/settings_screen.dart';
import 'package:dirronlive/ui/widgets/event_tile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

/// Файлы ровно в том виде, как их писала версия 0.1.0.
MemoryJsonStore storeFromVersion1() {
  final store = MemoryJsonStore();
  store.files[SettingsRepository.fileName] =
      jsonEncode({'version': 1, 'tiktokNickname': 'dirron_live'});
  store.files[EventHistoryRepository.fileName] = jsonEncode({
    'version': 1,
    'events': [
      for (var i = 3; i >= 1; i--)
        {
          'id': '00000000-0000-4000-8000-00000000000$i',
          'createdAt': '2026-11-22T19:3$i:05.000Z',
          'source': 'test',
          'viewerName': 'Тестовый зритель',
          'giftName': 'Роза',
          'count': 1,
        },
    ],
  });
  return store;
}

void main() {
  test('старые файлы читаются без предупреждений', () async {
    final data = await loadInitialData(storeFromVersion1());
    expect(data.warnings, isEmpty);
    expect(data.settings.tiktokNickname, 'dirron_live');
    expect(data.settings.minecraftLinkEnabled, isFalse);
    expect(data.history.length, 3);
    expect(data.history.every((e) => e.delivery == DeliveryStatus.logOnly),
        isTrue);
  });

  test('после сохранения ник и история остаются, поле доставки добавляется',
      () async {
    final store = storeFromVersion1();
    final container = createAppContainer(await loadInitialData(store));
    final log = container.read(eventLogProvider.notifier);
    log.setDelivery(
        '00000000-0000-4000-8000-000000000003', DeliveryStatus.logOnly);
    container.read(eventLogProvider.notifier).setDelivery(
        '00000000-0000-4000-8000-000000000001', DeliveryStatus.delivered);
    await log.flush();
    container.dispose();

    final saved = jsonDecode(store.files[EventHistoryRepository.fileName]!)
        as Map<String, Object?>;
    final events = (saved['events']! as List).cast<Map<String, Object?>>();
    expect(events.length, 3);
    expect(events.map((e) => e['delivery']),
        ['log_only', 'log_only', 'delivered']);

    final reloaded = await loadInitialData(store);
    expect(reloaded.settings.tiktokNickname, 'dirron_live');
    expect(reloaded.history.map((e) => e.delivery), [
      DeliveryStatus.logOnly,
      DeliveryStatus.logOnly,
      DeliveryStatus.delivered,
    ]);
  });

  test('«Отправляется» после перезапуска становится «не подтверждена»',
      () async {
    final store = storeFromVersion1();
    var container = createAppContainer(await loadInitialData(store));
    container
        .read(eventLogProvider.notifier)
        .setDelivery('00000000-0000-4000-8000-000000000002',
            DeliveryStatus.sending);
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();

    container = createAppContainer(await loadInitialData(store));
    final event = container
        .read(eventLogProvider)
        .byId('00000000-0000-4000-8000-000000000002');
    expect(event!.delivery, DeliveryStatus.unconfirmed);
    container.dispose();
  });

  test('связь не включается сама после обновления', () async {
    final container =
        createAppContainer(await loadInitialData(storeFromVersion1()));
    expect(container.read(minecraftLinkProvider).phase, LinkPhase.off);
    container.dispose();
  });

  testWidgets('интерфейс после обновления: ник и три старых записи',
      (tester) async {
    final container = await pumpDirronlive(tester, storeFromVersion1());
    expect(find.byType(EventTile), findsNWidgets(3));
    expect(find.text('Только в журнале'), findsNWidgets(3));

    await openSection(tester, 'history');
    expect(find.byType(HistoryRow), findsNWidgets(3));

    await openSection(tester, 'settings');
    final field =
        tester.widget<TextField>(find.byKey(SettingsScreen.nicknameFieldKey));
    expect(field.controller!.text, 'dirron_live');
    await closeDirronlive(tester, container);
  });
}
