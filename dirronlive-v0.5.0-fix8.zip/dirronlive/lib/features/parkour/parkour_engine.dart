import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/app_event.dart';
import '../../core/events/delivery_status.dart';
import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../../core/events/stream_events.dart';
import '../../core/providers.dart';
import '../events/event_log.dart';
import '../minecraft/link_protocol.dart';
import '../minecraft/minecraft_link.dart';
import 'action_catalog.dart';
import 'gift_catalog.dart';
import 'parkour_rules.dart';

final parkourEngineProvider = Provider<ParkourEngine>((ref) {
  final engine = ParkourEngine(ref);
  ref.onDispose(engine.dispose);
  return engine;
});

/// Какая запись истории последней запускала карточку: id карточки → id записи.
final parkourActivityProvider =
    NotifierProvider<ParkourActivity, Map<String, String>>(ParkourActivity.new);

class ParkourActivity extends Notifier<Map<String, String>> {
  @override
  Map<String, String> build() => const {};

  void set(String ruleId, String recordId) => state = {...state, ruleId: recordId};
}

/// Итог «Проверить в игре» или перехода в комнату.
class ActionOutcome {
  const ActionOutcome(this.ok, this.text);

  final bool ok;
  final String text;
}

/// Итог действия для оверлея «Действие зрителя» (после ответа мода).
class ViewerActionEvent extends AppEvent {
  ViewerActionEvent({
    required this.viewerName,
    required this.giftName,
    required this.actionId,
    required this.actionTitle,
    required this.result,
    required this.ok,
    required this.test,
    this.countdownSeconds = 0,
    this.pending = false,
  })  : id = generateEventId(),
        createdAt = DateTime.now();

  @override
  final String id;
  @override
  final DateTime createdAt;
  final String viewerName;
  final String giftName;
  final String actionId;
  final String actionTitle;
  final String result;
  final bool ok;
  final bool test;

  /// Отложенное действие («Второй шанс»): идёт отсчёт.
  final int countdownSeconds;
  final bool pending;
}

/// «1 000»
String formatCount(int n) {
  final s = '$n';
  final out = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) out.write(' ');
    out.write(s[i]);
  }
  return out.toString();
}

/// Срабатывания одной записи истории по одной карточке.
class _Track {
  _Track(this.recordId, this.rule);

  final String recordId;
  final GiftRule? rule;
  int sent = 0;
  bool held = false;
  bool cancelled = false;
  bool finalReported = false;
  Timer? holdTimer;
  Timer? silence;
  String countdownId = '';
  Completer<ModActionResult?>? waiter;

  String get key => '$recordId:${rule?.id ?? '-'}';
}

/// Правила «подарок → действие» на карте Dirron Parkour.
///
/// Одна штука подарка — одно срабатывание. Серия ×1 → ×2 → … → ×1000
/// отправляется в мод нарастающим «всего» по мере прихода шагов; мод
/// принимает только прирост и выполняет действия очередью по тикам.
/// Повтор шага (переподключение) ничего не добавляет. Прогресс от мода
/// («Выполнено 237 из 1 000») пишется в ту же запись истории.
class ParkourEngine {
  ParkourEngine(this._ref) {
    final bus = _ref.read(eventBusProvider);
    _giftSubscription = bus.on<GiftEvent>().listen(_onGift);
    // Лайки и подписка срабатывают как «подарки» «Лайки» и «Подписка».
    _likeSubscription = bus.on<LikeEvent>().listen(_onLike);
    _followSubscription = bus.on<FollowEvent>().listen(_onFollow);
    _resultSubscription =
        _ref.read(minecraftLinkProvider.notifier).actionResults.listen(_onResult);
  }

  final Ref<Object?> _ref;
  late final StreamSubscription<GiftEvent> _giftSubscription;
  late final StreamSubscription<LikeEvent> _likeSubscription;
  late final StreamSubscription<FollowEvent> _followSubscription;
  final Map<String, int> _likeRest = {};
  late final StreamSubscription<ModActionResult> _resultSubscription;
  final Map<String, _Track> _tracks = {};
  final Map<String, _Track> _byKey = {};
  final List<_Track> _held = [];
  final Map<String, GiftRule> _testRules = {};
  final Set<String> _unknownNoticed = {};
  int _serial = 0;
  bool _disposed = false;

  EventLogController get _log => _ref.read(eventLogProvider.notifier);
  MinecraftLinkController get _link => _ref.read(minecraftLinkProvider.notifier);
  Duration get _timeout => _ref.read(minecraftLinkConfigProvider).ackTimeout;

  /// Помехи, которые сейчас ждут «Второго шанса».
  int get heldCount => _held.length;

  GiftEvent? _record(String id) => _ref.read(eventLogProvider).byId(id);

  // ---------------------------------------------------------------- шина

  bool _hasRuleFor(String triggerId) => _ref
      .read(parkourRulesProvider)
      .rules
      .any((r) => r.enabled && r.giftId == triggerId);

  /// Каждые [likesPerTrigger] лайков зрителя — одно срабатывание карточки «Лайки».
  void _onLike(LikeEvent e) {
    if (_disposed || !_hasRuleFor(likesTriggerId)) return;
    final total = (_likeRest[e.viewerId] ?? 0) + e.likes;
    final n = total ~/ likesPerTrigger;
    _likeRest[e.viewerId] = total % likesPerTrigger;
    if (n <= 0) return;
    _publishSocial(e.source, e.viewerId, e.viewerName, e.viewerAvatar, likesTriggerId, 'Лайки', n,
        'likes:${e.sourceKey ?? generateEventId()}');
  }

  void _onFollow(FollowEvent e) {
    if (_disposed || !_hasRuleFor(followTriggerId)) return;
    _publishSocial(e.source, e.viewerId, e.viewerName, e.viewerAvatar, followTriggerId, 'Подписка', 1,
        'follow:${e.viewerId}');
  }

  void _publishSocial(EventSource source, String viewerId, String viewerName, String? avatar, String triggerId,
      String name, int count, String sourceKey) {
    _ref.read(eventBusProvider).publish(GiftEvent(
          id: generateEventId(),
          createdAt: _ref.read(clockProvider)(),
          source: source,
          viewerName: viewerName,
          viewerId: viewerId,
          viewerAvatar: avatar,
          giftName: name,
          giftId: triggerId,
          count: count,
          sourceKey: sourceKey,
        ));
  }

  void _onGift(GiftEvent step) {
    if (_disposed) return;
    final record = _ref.read(eventLogProvider).recordFor(step);
    if (record == null) return;
    var track = _tracks[record.id];
    if (track == null) {
      track = _start(record, step);
      if (track == null) return;
    }
    _sync(track);
  }

  /// Первый шаг записи: найти карточку, проверить готовность игры.
  _Track? _start(GiftEvent record, GiftEvent step) {
    if (_tracks.length > 5000) {
      final oldest = _tracks.keys.first;
      _byKey.remove(_tracks.remove(oldest)?.key);
    }
    var unknown = false;
    final giftId = record.giftId;
    if (record.source == EventSource.tiktok && giftId != null && !isSocialTrigger(giftId)) {
      final catalog = _ref.read(giftCatalogProvider.notifier);
      catalog.noteSeen(record);
      if (!catalog.knowsOrEmpty(giftId)) {
        unknown = true;
        if (_unknownNoticed.add(giftId)) {
          _ref.read(noticeServiceProvider).info(
              'Подарка «${record.giftName}» нет в сохранённом каталоге (новинка TikTok). '
              'Откройте «Каталог подарков» и нажмите «Обновить каталог».');
        }
      }
    }

    final rules = _ref.read(parkourRulesProvider);
    final testRule = step.comboId == null ? null : _testRules[step.comboId!];
    final rule = testRule ?? (rules.modeActive ? rules.ruleFor(record) : null);
    final track = _Track(record.id, rule);
    _tracks[record.id] = track;
    if (rule == null) {
      track.cancelled = true;
      if (unknown) _log.setAction(record.id, actionState: ActionState.none, unknownGift: true);
      return track;
    }
    _byKey[track.key] = track;
    _ref.read(parkourActivityProvider.notifier).set(rule.id, record.id);

    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) {
      track.cancelled = true;
      _log.setAction(record.id,
          actionState: ActionState.skipped,
          title: rule.actionTitle,
          result: blocker,
          unknownGift: unknown ? true : null);
      return track;
    }
    if (rule.actionId == 'second_chance') {
      track.cancelled = true;
      _secondChance(record, rule);
      return track;
    }
    final secondChance = rules.secondChance;
    if ((rule.action?.hindrance ?? false) && secondChance != null && record.source != EventSource.test) {
      _hold(track, record, rule, secondChance);
    }
    return track;
  }

  /// Отправить в мод прирост: «всего N штук».
  void _sync(_Track track) {
    final rule = track.rule;
    if (rule == null || track.cancelled || track.held) return;
    final record = _record(track.recordId);
    if (record == null) return;
    final total = record.count < 1 ? 1 : record.count;
    if (total <= track.sent) return; // повтор шага — ничего нового
    track.sent = total;
    track.finalReported = false;
    final sent = _link.sendAction(
      id: track.key,
      action: rule.actionId,
      params: rule.params,
      label: record.giftName,
      viewerName: record.viewerName,
      test: record.source == EventSource.test,
      total: total,
    );
    if (!sent) {
      _log.setAction(record.id,
          actionState: ActionState.failed,
          title: rule.actionTitle,
          result: 'связь с игрой оборвалась',
          delivery: record.source == EventSource.test ? DeliveryStatus.logOnly : null);
      track.waiter?.complete(null);
      return;
    }
    _log.setAction(record.id,
        actionState: ActionState.pending,
        title: rule.actionTitle,
        result: total == 1 ? 'отправляется в игру' : 'принято ${formatCount(total)}');
    track.silence?.cancel();
    track.silence = Timer(_timeout, () {
      if (_disposed || track.finalReported) return;
      final current = _record(track.recordId);
      if (current?.actionState != ActionState.pending) return;
      _log.setAction(track.recordId,
          actionState: ActionState.failed,
          result: 'игра не ответила за ${_timeout.inSeconds} с',
          delivery: current!.source == EventSource.test ? DeliveryStatus.unconfirmed : null);
      final waiter = track.waiter;
      if (waiter != null && !waiter.isCompleted) waiter.complete(null);
    });
  }

  void _onResult(ModActionResult result) {
    final track = _byKey[result.id];
    if (track == null) return;
    final record = _record(track.recordId);
    if (record == null) return;
    track.silence?.cancel();
    final isTest = record.source == EventSource.test;
    final complete = result.finished && result.done >= track.sent;
    if (!complete) {
      if (track.finalReported) return;
      _log.setAction(record.id,
          actionState: ActionState.pending,
          result: result.accepted > 1
              ? 'Выполнено ${formatCount(result.done)} из ${formatCount(result.accepted)}'
                  ' · в очереди ${formatCount(result.queued)}'
              : 'выполняется');
      // Молчание дольше таймаута после прогресса — тоже повод сказать.
      track.silence = Timer(_timeout * 6, () {
        if (_disposed || track.finalReported) return;
        _log.setAction(track.recordId,
            actionState: ActionState.failed, result: 'игра перестала отвечать');
      });
      return;
    }
    track.finalReported = true;
    final text = result.result.isEmpty ? (result.ok ? 'выполнено' : 'не выполнено') : result.result;
    // Серия: сколько принято, выполнено и сколько ещё в очереди.
    final shown = result.accepted > 1
        ? '$text · принято ${formatCount(result.accepted)}, выполнено ${formatCount(result.done)}, '
            'в очереди ${formatCount(result.queued)}'
        : text;
    _log.setAction(record.id,
        actionState: result.ok ? ActionState.done : ActionState.failed,
        result: shown,
        delivery: isTest
            ? (result.ok ? DeliveryStatus.delivered : DeliveryStatus.logOnly)
            : null);
    final rule = track.rule!;
    _ref.read(eventBusProvider).publish(ViewerActionEvent(
          viewerName: record.viewerName,
          giftName: record.giftName,
          actionId: rule.actionId,
          actionTitle: rule.actionTitle,
          result: shown,
          ok: result.ok,
          test: isTest,
        ));
    final waiter = track.waiter;
    if (waiter != null && !waiter.isCompleted) waiter.complete(result);
  }

  // ------------------------------------------------------- второй шанс

  void _hold(_Track track, GiftEvent record, GiftRule rule, GiftRule secondChance) {
    final seconds = (secondChance.params['seconds'] as num?)?.toInt() ?? 10;
    track.held = true;
    track.countdownId = 'sc-${record.id}';
    _link.sendCountdown(track.countdownId,
        '«${rule.actionTitle}» от ${record.viewerName} — «${secondChance.giftName}» отменит', seconds);
    _log.setAction(record.id,
        actionState: ActionState.pending,
        title: rule.actionTitle,
        result: 'ждёт $seconds с: «${secondChance.giftName}» может отменить');
    _ref.read(eventBusProvider).publish(ViewerActionEvent(
          viewerName: record.viewerName,
          giftName: record.giftName,
          actionId: rule.actionId,
          actionTitle: rule.actionTitle,
          result: 'через $seconds с, если чат не отменит',
          ok: true,
          test: false,
          countdownSeconds: seconds,
          pending: true,
        ));
    track.holdTimer = Timer(Duration(seconds: seconds), () {
      if (_disposed || !_held.remove(track)) return;
      track.held = false;
      _sync(track);
    });
    _held.add(track);
  }

  void _secondChance(GiftEvent record, GiftRule rule) {
    if (_held.isEmpty) {
      _log.setAction(record.id,
          actionState: ActionState.done, title: rule.actionTitle, result: 'Нечего отменять — помех нет');
      return;
    }
    final held = _held.removeAt(0);
    held.holdTimer?.cancel();
    held.cancelled = true;
    final heldRecord = _record(held.recordId);
    final heldTitle = held.rule?.actionTitle ?? 'Действие';
    _link.sendCountdown(held.countdownId, 'Чат спас: «$heldTitle» отменена', 0);
    _log.setAction(held.recordId,
        actionState: ActionState.skipped,
        title: heldTitle,
        result: 'отменено «Вторым шансом» от ${record.viewerName}');
    _log.setAction(record.id,
        actionState: ActionState.done,
        title: rule.actionTitle,
        result: 'Отменил «$heldTitle» от ${heldRecord?.viewerName ?? 'зрителя'}');
    _ref.read(eventBusProvider).publish(ViewerActionEvent(
          viewerName: record.viewerName,
          giftName: record.giftName,
          actionId: 'second_chance',
          actionTitle: rule.actionTitle,
          result: 'отменил «$heldTitle»',
          ok: true,
          test: false,
        ));
  }

  // ------------------------------------------------------- проверки

  /// «Проверить в игре»: одно срабатывание карточки и запись
  /// «Тест · Комната 12 → 11». Работает без эфира и без подарка.
  Future<ActionOutcome> test(GiftRule rule) async {
    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) return ActionOutcome(false, blocker);
    final action = rule.action;
    if (action == null) return const ActionOutcome(false, 'Неизвестное действие');
    final record = GiftEvent(
      id: generateEventId(),
      createdAt: _ref.read(clockProvider)(),
      source: EventSource.test,
      viewerName: 'Тест',
      giftName: rule.hasGift ? rule.giftName : 'Проверка',
      count: 1,
      giftId: rule.giftId,
      delivery: DeliveryStatus.sending,
      actionTitle: action.title,
      actionState: ActionState.pending,
      actionResult: 'отправляется в игру',
    );
    _log.add(record);
    _ref.read(parkourActivityProvider.notifier).set(rule.id, record.id);

    if (action.id == 'second_chance') {
      final seconds = (rule.params['seconds'] as num?)?.toInt() ?? 10;
      final sent = _link.sendCountdown('test-sc-${_serial++}', 'Проверка: «Второй шанс от чата»', seconds);
      final text = sent ? 'Обратный отсчёт $seconds с показан в игре' : 'связь с игрой оборвалась';
      _log.setAction(record.id,
          actionState: sent ? ActionState.done : ActionState.failed,
          result: text,
          delivery: sent ? DeliveryStatus.delivered : DeliveryStatus.logOnly);
      return ActionOutcome(sent, sent ? 'Тест · $text' : text);
    }

    final track = _Track(record.id, rule);
    _tracks[record.id] = track;
    _byKey[track.key] = track;
    final waiter = Completer<ModActionResult?>();
    track.waiter = waiter;
    _sync(track);
    final result = await waiter.future;
    if (_disposed) return const ActionOutcome(false, 'Программа закрывается');
    final text = _record(record.id)?.actionResult ?? 'нет ответа';
    if (result == null) return ActionOutcome(false, text);
    return ActionOutcome(result.ok, result.ok ? 'Тест · $text' : text);
  }

  /// Тестовая серия ×[units] без настоящих подарков: идёт по той же
  /// дороге, что и эфир (шина → статистика, оверлеи, очередь мода), только
  /// помечена «Тест». Шаги нарастают, в конце — повтор последнего шага,
  /// который ничего не должен добавить. Возвращает id записи истории.
  Future<String?> testSeries(GiftRule rule, {int units = 1000, Duration pace = const Duration(milliseconds: 40)}) async {
    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) return null;
    final comboId = 'test-series-${generateEventId()}';
    _testRules[comboId] = rule;
    final bus = _ref.read(eventBusProvider);
    final clock = _ref.read(clockProvider);
    final steps = <int>{};
    for (var n = 1; n < units; n = n < 10 ? n + 1 : (n * 1.6).ceil()) {
      steps.add(n);
    }
    steps.add(units);
    String? recordId;
    GiftEvent step(int n, {required bool active}) => GiftEvent(
          id: generateEventId(),
          createdAt: clock(),
          source: EventSource.test,
          viewerName: 'Тест',
          viewerId: 'test-viewer',
          giftName: rule.hasGift ? rule.giftName : 'Проверка',
          giftId: rule.giftId,
          giftImage: rule.imageUrl,
          count: n,
          comboId: comboId,
          comboActive: active,
          sourceKey: comboId,
        );
    for (final n in steps) {
      if (_disposed) return recordId;
      bus.publish(step(n, active: n < units));
      await Future<void>.delayed(pace);
      recordId ??= _ref.read(eventLogProvider).byComboId(comboId)?.id;
    }
    // Повтор последнего шага (как после переподключения) — без прибавки.
    bus.publish(step(units, active: false));
    final track = recordId == null ? null : _tracks[recordId];
    if (track != null && track.rule != null) {
      // И повтор того же «всего» в мод: очередь должна его отбросить.
      _link.sendAction(
        id: track.key,
        action: track.rule!.actionId,
        params: track.rule!.params,
        label: 'Тест',
        viewerName: 'Тест',
        test: true,
        total: units,
      );
    }
    return recordId;
  }

  /// Перенос на старт комнаты [room] (подготовка к проверке).
  Future<ActionOutcome> goToRoom(int room) async {
    final blocker = _ref.read(minecraftLinkProvider).parkourBlocker;
    if (blocker != null) return ActionOutcome(false, blocker);
    final id = 'goto-${DateTime.now().microsecondsSinceEpoch}-${_serial++}';
    final completer = Completer<ModActionResult?>();
    late final StreamSubscription<ModActionResult> sub;
    sub = _link.actionResults.listen((r) {
      if (r.id == id && r.finished && !completer.isCompleted) completer.complete(r);
    });
    final sent = _link.sendAction(
      id: id,
      action: 'goto_room',
      params: {'room': room},
      label: '',
      viewerName: '',
      test: true,
    );
    if (!sent) {
      unawaited(sub.cancel());
      return const ActionOutcome(false, 'связь с игрой оборвалась');
    }
    final result = await completer.future.timeout(_timeout, onTimeout: () => null);
    // Отписку не ждём: её Future может не завершиться (поддельное время в тестах).
    unawaited(sub.cancel());
    if (result == null) return ActionOutcome(false, 'Игра не ответила за ${_timeout.inSeconds} с');
    return ActionOutcome(result.ok, result.result);
  }

  void dispose() {
    _disposed = true;
    unawaited(_giftSubscription.cancel());
    unawaited(_likeSubscription.cancel());
    unawaited(_followSubscription.cancel());
    unawaited(_resultSubscription.cancel());
    for (final track in _tracks.values) {
      track.holdTimer?.cancel();
      track.silence?.cancel();
      final waiter = track.waiter;
      if (waiter != null && !waiter.isCompleted) waiter.complete(null);
    }
    _held.clear();
  }
}

/// Для подсказки: какие действия — помехи.
bool isHindrance(String actionId) => parkourActionById(actionId)?.hindrance ?? false;
