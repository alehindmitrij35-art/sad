import 'package:flutter/material.dart';

import '../ui/theme/app_colors.dart';

/// Короткие сообщения внизу окна (SnackBar).
/// Работает из любого места: из контроллеров, не только из виджетов.
class NoticeService {
  NoticeService(this._messengerKey);

  final GlobalKey<ScaffoldMessengerState> _messengerKey;

  void info(String message) => _show(message, isError: false);

  void error(String message) => _show(message, isError: true);

  void _show(String message, {required bool isError}) {
    final ScaffoldMessengerState? messenger;
    try {
      messenger = _messengerKey.currentState;
    } catch (_) {
      // Интерфейс ещё не создан (например, в тестах без окна) — показывать негде.
      return;
    }
    if (messenger == null) return;
    // Свежее сообщение важнее: не ставим его в очередь за старым.
    messenger.removeCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.surfaceHigh,
        duration: Duration(seconds: isError ? 8 : 3),
        showCloseIcon: isError,
        closeIconColor: AppColors.textMuted,
        content: Row(
          children: [
            Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: isError ? AppColors.danger : AppColors.success,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(color: AppColors.text, fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
