@echo off
rem Dirronlive Bridge: builds build\libs\DirronliveBridge-2.1.0.jar
cd /d "%~dp0"
if exist "%USERPROFILE%\.jdks\openjdk-21.0.2\bin\java.exe" set "JAVA_HOME=%USERPROFILE%\.jdks\openjdk-21.0.2"
call gradlew.bat build || goto :fail
echo.
echo DONE: build\libs\DirronliveBridge-2.1.0.jar
explorer build\libs
pause
exit /b 0
:fail
echo BUILD FAILED
pause
exit /b 1
