package dev.dirronlive.parkour.world;

import dev.dirronlive.parkour.map.ParkourLayout;
import dev.dirronlive.parkour.map.Platform;
import dev.dirronlive.parkour.map.RoomPlan;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * 23 действия за подарки. Каждое возвращает понятный результат для истории
 * Dirronlive («Комната 12 → 11», «Суперсильный толчок вправо»).
 * Вызывается только в потоке сервера.
 */
public final class ParkourActions {
    private ParkourActions() {}

    public record Outcome(boolean ok, String text) {}

    /** Действия с меткой «помеха» — их гасит «Щит от пакости». */
    public static final Set<String> HINDRANCES = Set.of(
            "room_back", "big_rollback", "restart_room", "heavy_boots", "freeze", "push",
            "vanishing_step", "to_first_level", "super_push");

    public static final Map<String, String> TITLES = Map.ofEntries(
            Map.entry("room_forward", "Комната вперёд"),
            Map.entry("room_back", "Комната назад"),
            Map.entry("big_rollback", "Большой откат"),
            Map.entry("restart_room", "Снова со старта"),
            Map.entry("fall_rescue", "Спасение от падения"),
            Map.entry("personal_checkpoint", "Личный чекпоинт"),
            Map.entry("champion_jump", "Прыжок чемпиона"),
            Map.entry("sprint", "Спринт"),
            Map.entry("heavy_boots", "Тяжёлые ботинки"),
            Map.entry("freeze", "Заморозка"),
            Map.entry("push", "Толчок"),
            Map.entry("lightning", "Удар молнией"),
            Map.entry("trampoline", "Батут под ногами"),
            Map.entry("soft_landing", "Мягкая посадка"),
            Map.entry("safety_platform", "Страховочная платформа"),
            Map.entry("viewer_bridge", "Мост зрителя"),
            Map.entry("secret_shortcut", "Секретная срезка"),
            Map.entry("vanishing_step", "Исчезающая ступень"),
            Map.entry("show_route", "Покажи маршрут"),
            Map.entry("shield", "Щит от пакости"),
            Map.entry("second_chance", "Второй шанс от чата"),
            Map.entry("to_last_level", "На последний уровень"),
            Map.entry("to_first_level", "На первый уровень"),
            Map.entry("super_push", "СУПЕР СИЛЬНЫЙ ТОЛЧОК"));

    /** Базовая сила «Толчка» (блоков за тик по горизонтали). */
    static final double PUSH_BASE = 0.6;

    static final Identifier FREEZE_SPEED = Identifier.of("dirronlive", "freeze_speed");
    static final Identifier FREEZE_JUMP = Identifier.of("dirronlive", "freeze_jump");

    /**
     * Выполнить действие. {@code label} — подарок, который его вызвал
     * (для щита и надписей), например «Роза».
     */
    public static Outcome apply(ParkourWorld pw, ServerPlayerEntity player, String action,
                                Map<String, Object> params, String label) {
        return apply(pw, player, action, params, label, false);
    }

    /**
     * {@code quiet} — без надписи на весь экран (повторные срабатывания серии:
     * прогресс показывается строкой над хотбаром).
     */
    public static Outcome apply(ParkourWorld pw, ServerPlayerEntity player, String action,
                                Map<String, Object> params, String label, boolean quiet) {
        if (!pw.state.built) return new Outcome(false, "Это не мир Dirron Parkour");
        String title = action.equals("goto_room") ? "Переход" : TITLES.get(action);
        if (title == null) return new Outcome(false, "Неизвестное действие: " + action);
        PlayerProgress p = pw.progress(player);

        if (HINDRANCES.contains(action) && p.shieldCharges > 0) {
            p.shieldCharges--;
            pw.state.markDirty();
            String shieldFrom = p.shieldLabel.isEmpty() ? "подарка" : "«" + p.shieldLabel + "»";
            String text = "Щит от " + shieldFrom + " погасил «" + title + "»";
            if (!quiet) pw.title(player, Text.literal("Щит!").formatted(Formatting.AQUA, Formatting.BOLD), Text.literal(text));
            pw.world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1f, 1f);
            return new Outcome(true, text);
        }

        Outcome outcome = switch (action) {
            case "room_forward" -> moveRooms(pw, player, p, intParam(params, "rooms", 1, 1, 99), "");
            case "room_back" -> moveRooms(pw, player, p, -intParam(params, "rooms", 1, 1, 99), "");
            case "big_rollback" -> moveRooms(pw, player, p, -intParam(params, "rooms", 5, 1, 99), "Большой откат: ");
            case "to_last_level" -> moveTo(pw, player, p, ParkourLayout.ROOMS, "");
            case "to_first_level" -> moveTo(pw, player, p, 1, "");
            case "goto_room" -> moveTo(pw, player, p, intParam(params, "room", p.room, 1, ParkourLayout.ROOMS), "");
            case "restart_room" -> {
                RoomPlan plan = pw.plan(p.room);
                pw.teleport(player, plan.spawnX, plan.spawnY, plan.spawnZ, plan.spawnYaw);
                yield new Outcome(true, "Снова со старта: комната " + p.room);
            }
            case "fall_rescue" -> {
                p.rescueCharges += intParam(params, "charges", 1, 1, 10);
                pw.state.markDirty();
                yield new Outcome(true, "Спасение от падения: зарядов " + p.rescueCharges);
            }
            case "personal_checkpoint" -> personalCheckpoint(pw, player, p);
            case "champion_jump" -> effect(pw, player, "champion_jump", "Прыжок чемпиона",
                    intParam(params, "seconds", 5, 1, 60), intParam(params, "power", 2, 1, 5), BossBar.Color.GREEN);
            case "sprint" -> effect(pw, player, "sprint", "Спринт",
                    intParam(params, "seconds", 5, 1, 60), intParam(params, "power", 2, 1, 5), BossBar.Color.YELLOW);
            case "heavy_boots" -> effect(pw, player, "heavy_boots", "Тяжёлые ботинки",
                    intParam(params, "seconds", 4, 1, 60), intParam(params, "power", 2, 1, 5), BossBar.Color.RED);
            case "soft_landing" -> effect(pw, player, "soft_landing", "Мягкая посадка",
                    intParam(params, "seconds", 6, 1, 60), 1, BossBar.Color.BLUE);
            case "freeze" -> freeze(pw, player, intParam(params, "seconds", 2, 1, 15));
            case "lightning" -> lightning(pw, player, PUSH_BASE * doubleParam(params, "strength", 1.5, 0.3, 5.0));
            case "push" -> push(player, stringParam(params, "direction", "random"),
                    PUSH_BASE * doubleParam(params, "strength", 1.0, 0.1, 5.0), 0.25, false);
            case "super_push" -> push(player, stringParam(params, "direction", "random"),
                    PUSH_BASE * doubleParam(params, "strength", 3.0, 0.5, 10.0),
                    doubleParam(params, "lift", 0.8, 0.0, 3.0), true);
            case "trampoline" -> trampoline(pw, player, doubleParam(params, "power", 1.2, 0.4, 3.0));
            case "safety_platform" -> {
                pw.session(player).safetySeconds = intParam(params, "seconds", 3, 1, 30);
                yield new Outcome(true, "Страховочная платформа наготове");
            }
            case "viewer_bridge" -> tempBlocks(pw, player, pw.plan(p.room).bridge,
                    Blocks.LIME_STAINED_GLASS.getDefaultState(), intParam(params, "seconds", 5, 1, 60), "Мост зрителя");
            case "secret_shortcut" -> tempBlocks(pw, player, pw.plan(p.room).shortcut,
                    Blocks.MAGENTA_GLAZED_TERRACOTTA.getDefaultState(), intParam(params, "seconds", 8, 1, 60),
                    "Секретная срезка");
            case "vanishing_step" -> vanishingStep(pw, player, p, intParam(params, "seconds", 3, 1, 30));
            case "show_route" -> showRoute(pw, player, p, intParam(params, "seconds", 5, 1, 60));
            case "shield" -> {
                p.shieldCharges += intParam(params, "charges", 1, 1, 10);
                p.shieldLabel = label == null ? "" : label;
                pw.state.markDirty();
                yield new Outcome(true, "Щит от «" + (label == null || label.isEmpty() ? "подарка" : label)
                        + "»: зарядов " + p.shieldCharges);
            }
            case "second_chance" -> new Outcome(false, "«Второй шанс» запускает Dirronlive с обратным отсчётом");
            default -> new Outcome(false, "Неизвестное действие: " + action);
        };
        if (outcome.ok() && !quiet && !action.equals("goto_room")) {
            pw.title(player, Text.literal(title).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                    Text.literal((label == null || label.isEmpty() ? "" : label + " · ") + outcome.text()));
        }
        pw.updateStatus(player);
        return outcome;
    }

    // ------------------------------------------------------------ комнаты

    static Outcome moveRooms(ParkourWorld pw, ServerPlayerEntity player, PlayerProgress p, int delta, String prefix) {
        return moveTo(pw, player, p, p.room + delta, prefix);
    }

    static Outcome moveTo(ParkourWorld pw, ServerPlayerEntity player, PlayerProgress p, int target, String prefix) {
        int from = p.room;
        int to = Math.max(1, Math.min(ParkourLayout.ROOMS, target));
        pw.moveToRoom(player, to);
        return new Outcome(true, prefix + "Комната " + from + " → " + to);
    }

    static Outcome personalCheckpoint(ParkourWorld pw, ServerPlayerEntity player, PlayerProgress p) {
        Runnable place = () -> {
            p.cpX = player.getX();
            p.cpY = player.getY();
            p.cpZ = player.getZ();
            p.cpYaw = player.getYaw();
            p.personalCheckpoint = true;
            pw.state.markDirty();
            pw.world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 0.2, player.getZ(),
                    30, 0.6, 0.2, 0.6, 0.0);
            pw.actionbar(player, Text.literal("Личный чекпоинт поставлен").formatted(Formatting.GREEN));
        };
        if (player.isOnGround()) {
            place.run();
            return new Outcome(true, "Личный чекпоинт поставлен");
        }
        pw.session(player).onLanding.add(place);
        return new Outcome(true, "Личный чекпоинт: ждёт приземления");
    }

    // ------------------------------------------------------------ эффекты

    static Outcome effect(ParkourWorld pw, ServerPlayerEntity player, String id, String title,
                          int seconds, int power, BossBar.Color color) {
        int ticks = seconds * 20;
        int amplifier = Math.max(0, power - 1);
        var effect = switch (id) {
            case "champion_jump" -> StatusEffects.JUMP_BOOST;
            case "sprint" -> StatusEffects.SPEED;
            case "heavy_boots" -> StatusEffects.SLOWNESS;
            default -> StatusEffects.SLOW_FALLING;
        };
        // Каждый подарок продлевает эффект (не больше 20 минут).
        StatusEffectInstance current = player.getStatusEffect(effect);
        int total = ticks;
        if (current != null && current.getAmplifier() == amplifier) {
            total = (int) Math.min(24_000L, (long) current.getDuration() + ticks);
        }
        player.addStatusEffect(new StatusEffectInstance(effect, total, amplifier, false, true, true));
        pw.showBar(player, id, title, total, color);
        return new Outcome(true, title + " на " + seconds + " с");
    }

    static Outcome freeze(ParkourWorld pw, ServerPlayerEntity player, int seconds) {
        EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        EntityAttributeInstance jump = player.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH);
        if (speed != null) {
            speed.removeModifier(FREEZE_SPEED);
            speed.addTemporaryModifier(new EntityAttributeModifier(FREEZE_SPEED, -1.0,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        if (jump != null) {
            jump.removeModifier(FREEZE_JUMP);
            jump.addTemporaryModifier(new EntityAttributeModifier(FREEZE_JUMP, -1.0,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;
        ParkourWorld.Session session = pw.session(player);
        long until = Math.min(pw.now() + 24_000, Math.max(session.freezeUntil, pw.now()) + seconds * 20L);
        session.freezeUntil = until;
        int ticks = (int) (until - pw.now());
        pw.showBar(player, "freeze", "Заморозка", ticks, BossBar.Color.WHITE);
        pw.scheduler.at(until, () -> {
            if (pw.now() >= session.freezeUntil) unfreeze(player);
        });
        pw.world.spawnParticles(ParticleTypes.SNOWFLAKE, player.getX(), player.getY() + 1, player.getZ(), 40, 0.4, 0.8, 0.4, 0.02);
        return new Outcome(true, "Заморозка на " + seconds + " с");
    }

    public static void unfreeze(ServerPlayerEntity player) {
        EntityAttributeInstance speed = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        EntityAttributeInstance jump = player.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH);
        if (speed != null) speed.removeModifier(FREEZE_SPEED);
        if (jump != null) jump.removeModifier(FREEZE_JUMP);
    }

    static final Map<String, String> DIRECTION_WORDS = Map.of(
            "forward", "вперёд", "back", "назад", "left", "влево", "right", "вправо");

    /** Толчок относительно взгляда игрока. */
    static Outcome push(ServerPlayerEntity player, String direction, double horizontal, double lift, boolean superPush) {
        Vec3d v;
        String word;
        if ("random".equals(direction) || !DIRECTION_WORDS.containsKey(direction)) {
            // Случайная сторона: любой угол по горизонтали.
            v = randomHorizontal(player).multiply(horizontal);
            word = "в случайную сторону";
        } else {
            v = directionVector(player.getYaw(), direction).multiply(horizontal);
            word = DIRECTION_WORDS.get(direction);
        }
        player.addVelocity(v.x, lift, v.z);
        player.velocityModified = true;
        return new Outcome(true, (superPush ? "Суперсильный толчок " : "Толчок ") + word);
    }

    static Vec3d randomHorizontal(ServerPlayerEntity player) {
        double a = player.getRandom().nextDouble() * Math.PI * 2;
        return new Vec3d(Math.cos(a), 0, Math.sin(a));
    }

    /** Молния рядом с игроком — только эффект (без огня и урона) — и отдача в случайную сторону. */
    static Outcome lightning(ParkourWorld pw, ServerPlayerEntity player, double horizontal) {
        net.minecraft.entity.LightningEntity bolt = net.minecraft.entity.EntityType.LIGHTNING_BOLT.create(pw.world);
        if (bolt != null) {
            bolt.setCosmetic(true);
            bolt.refreshPositionAfterTeleport(player.getX(), player.getY(), player.getZ());
            pw.world.spawnEntity(bolt);
        }
        Vec3d v = randomHorizontal(player).multiply(horizontal);
        player.addVelocity(v.x, 0.55, v.z);
        player.velocityModified = true;
        return new Outcome(true, "Удар молнией: отбросило в случайную сторону");
    }

    /** Направление по горизонтали: вперёд/назад/влево/вправо от взгляда. */
    public static Vec3d directionVector(float yawDegrees, String direction) {
        double yaw = Math.toRadians(yawDegrees);
        Vec3d forward = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        return switch (direction) {
            case "back" -> forward.multiply(-1);
            case "left" -> right.multiply(-1);
            case "right" -> right;
            default -> forward;
        };
    }

    static Outcome trampoline(ParkourWorld pw, ServerPlayerEntity player, double power) {
        Runnable bounce = () -> {
            player.setVelocity(player.getVelocity().x, power, player.getVelocity().z);
            player.velocityModified = true;
            pw.world.playSound(null, player.getBlockPos(), SoundEvents.BLOCK_SLIME_BLOCK_FALL, SoundCategory.PLAYERS, 1f, 1f);
        };
        if (player.isOnGround()) {
            bounce.run();
            return new Outcome(true, "Батут под ногами");
        }
        pw.session(player).onLanding.add(bounce);
        return new Outcome(true, "Батут под ногами: сработает после приземления");
    }

    // ---------------------------------------------------- временные блоки

    static Outcome tempBlocks(ParkourWorld pw, ServerPlayerEntity player, List<int[]> points, BlockState block,
                              int seconds, String title) {
        List<BlockPos> positions = new ArrayList<>();
        for (int[] p : points) positions.add(new BlockPos(p[0], p[1], p[2]));
        if (positions.isEmpty()) return new Outcome(false, title + ": в этой комнате нет места");
        pw.temp.place(pw.world, positions, block, pw.now(), seconds * 20);
        for (BlockPos pos : positions) {
            if (pos.hashCode() % 3 == 0) {
                pw.world.spawnParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 2, 0.2, 0.2, 0.2, 0.01);
            }
        }
        pw.world.playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1f, 1.2f);
        return new Outcome(true, title + " на " + seconds + " с");
    }

    static Outcome vanishingStep(ParkourWorld pw, ServerPlayerEntity player, PlayerProgress p, int seconds) {
        RoomPlan plan = pw.plan(p.room);
        int here = plan.nearestPlatform(player.getX(), player.getY(), player.getZ());
        Platform target = null;
        for (int index : plan.vanishCandidates) {
            if (index > here) {
                target = plan.platforms.get(index);
                break;
            }
        }
        if (target == null) return new Outcome(false, "Исчезающая ступень: впереди только финиш");
        List<BlockPos> blocks = new ArrayList<>();
        for (int x = target.x0(); x <= target.x1(); x++) {
            for (int z = target.z0(); z <= target.z1(); z++) {
                blocks.add(new BlockPos(x, target.y(), z));
                blocks.add(new BlockPos(x, target.y() - 1, z));
            }
        }
        // Мигает секунду, затем исчезает и возвращается.
        BlockState warn = Blocks.RED_STAINED_GLASS.getDefaultState();
        long now = pw.now();
        pw.temp.place(pw.world, blocks, warn, now, 5);
        pw.scheduler.at(now + 10, () -> pw.temp.place(pw.world, blocks, warn, pw.now(), 5));
        pw.scheduler.at(now + 20, () -> pw.temp.place(pw.world, blocks, Blocks.AIR.getDefaultState(), pw.now(), seconds * 20));
        return new Outcome(true, "Исчезающая ступень: платформа " + target.index() + " на " + seconds + " с");
    }

    static Outcome showRoute(ParkourWorld pw, ServerPlayerEntity player, PlayerProgress p, int seconds) {
        RoomPlan plan = pw.plan(p.room);
        int ticks = seconds * 20;
        long start = pw.now();
        for (long t = 0; t < ticks; t += 4) {
            pw.scheduler.at(start + t, () -> {
                if (pw.progress(player).room != plan.number) return;
                int here = plan.nearestPlatform(player.getX(), player.getY(), player.getZ());
                for (int i = here; i < Math.min(here + 3, plan.platforms.size() - 1); i++) {
                    Platform a = plan.platforms.get(i), b = plan.platforms.get(i + 1);
                    double ax = a.centerX(), az = a.centerZ(), ay = a.y() + 1.6;
                    double bx = b.centerX(), bz = b.centerZ(), by = b.y() + 1.6;
                    for (int s = 0; s <= 8; s++) {
                        double f = s / 8.0;
                        double arc = Math.sin(Math.PI * f) * 1.2;
                        pw.world.spawnParticles(ParticleTypes.END_ROD, ax + (bx - ax) * f, ay + (by - ay) * f + arc,
                                az + (bz - az) * f, 1, 0, 0, 0, 0);
                    }
                    pw.world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, bx, by, bz, 4, 0.3, 0.1, 0.3, 0);
                }
            });
        }
        pw.showBar(player, "show_route", "Маршрут от зрителей", ticks, BossBar.Color.PURPLE);
        return new Outcome(true, "Маршрут подсвечен на " + seconds + " с");
    }

    // ---------------------------------------------------------- параметры

    static int intParam(Map<String, Object> params, String key, int def, int min, int max) {
        Object v = params == null ? null : params.get(key);
        int value = v instanceof Number n ? (int) Math.round(n.doubleValue()) : def;
        return Math.max(min, Math.min(max, value));
    }

    static double doubleParam(Map<String, Object> params, String key, double def, double min, double max) {
        Object v = params == null ? null : params.get(key);
        double value = v instanceof Number n ? n.doubleValue() : def;
        return Math.max(min, Math.min(max, value));
    }

    static String stringParam(Map<String, Object> params, String key, String def) {
        Object v = params == null ? null : params.get(key);
        return v instanceof String s && !s.isEmpty() ? s : def;
    }
}
