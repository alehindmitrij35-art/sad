package dev.dirronlive.parkour.world;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtLong;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

/** Данные карты в сохранении мира: построена ли карта, прогресс игроков, «грязные» блоки. */
public final class ParkourState extends PersistentState {
    public static final String ID = "dirron_parkour";

    public boolean built;
    public int baseX, baseY = 100, baseZ;
    public boolean eyesLit;
    public final Map<UUID, PlayerProgress> players = new HashMap<>();
    /** Позиции временных блоков: при загрузке мира их исправляем по чертежу. */
    public final Set<Long> dirty = new HashSet<>();

    public static final PersistentState.Type<ParkourState> TYPE = new PersistentState.Type<>(
            ParkourState::new, ParkourState::fromNbt, DataFixTypes.LEVEL);

    public static ParkourState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE, ID);
    }

    public PlayerProgress progress(UUID id) {
        return players.computeIfAbsent(id, k -> {
            markDirty();
            return new PlayerProgress();
        });
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putBoolean("built", built);
        nbt.putInt("baseX", baseX);
        nbt.putInt("baseY", baseY);
        nbt.putInt("baseZ", baseZ);
        nbt.putBoolean("eyesLit", eyesLit);
        NbtCompound ps = new NbtCompound();
        players.forEach((id, p) -> ps.put(id.toString(), p.write()));
        nbt.put("players", ps);
        NbtList d = new NbtList();
        for (long pos : dirty) d.add(NbtLong.of(pos));
        nbt.put("dirty", d);
        return nbt;
    }

    static ParkourState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        ParkourState s = new ParkourState();
        s.built = nbt.getBoolean("built");
        s.baseX = nbt.getInt("baseX");
        s.baseY = nbt.contains("baseY") ? nbt.getInt("baseY") : 100;
        s.baseZ = nbt.getInt("baseZ");
        s.eyesLit = nbt.getBoolean("eyesLit");
        NbtCompound ps = nbt.getCompound("players");
        for (String key : ps.getKeys()) {
            try {
                s.players.put(UUID.fromString(key), PlayerProgress.read(ps.getCompound(key)));
            } catch (IllegalArgumentException ignored) {
                // повреждённая запись
            }
        }
        NbtList d = nbt.getList("dirty", NbtElement.LONG_TYPE);
        for (int i = 0; i < d.size(); i++) {
            if (d.get(i) instanceof NbtLong l) s.dirty.add(l.longValue());
        }
        return s;
    }
}
