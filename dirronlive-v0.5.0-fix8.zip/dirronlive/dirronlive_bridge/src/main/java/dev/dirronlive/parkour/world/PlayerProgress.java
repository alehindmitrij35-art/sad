package dev.dirronlive.parkour.world;

import net.minecraft.nbt.NbtCompound;

/** Прогресс игрока: сохраняется в мире и переживает выход из игры. */
public final class PlayerProgress {
    public int room = 1;
    public double cpX, cpY, cpZ;
    public float cpYaw;
    /** Чекпоинт поставлен действием «Личный чекпоинт». */
    public boolean personalCheckpoint;
    public boolean hasCheckpoint;
    public int falls;
    public long ticks;
    public boolean finished;
    public int rescueCharges;
    public int shieldCharges;
    public String shieldLabel = "";
    /** Падения в текущей комнате (попытка = roomFalls + 1); телепорт обнуляет. */
    public int roomFalls;
    /** Рекорд забега: самая дальняя комната и лучшее время прохождения. */
    public int bestRoom = 1;
    public long bestTicks;

    NbtCompound write() {
        NbtCompound n = new NbtCompound();
        n.putInt("room", room);
        n.putDouble("cpX", cpX);
        n.putDouble("cpY", cpY);
        n.putDouble("cpZ", cpZ);
        n.putFloat("cpYaw", cpYaw);
        n.putBoolean("personal", personalCheckpoint);
        n.putBoolean("hasCp", hasCheckpoint);
        n.putInt("falls", falls);
        n.putLong("ticks", ticks);
        n.putBoolean("finished", finished);
        n.putInt("rescue", rescueCharges);
        n.putInt("shield", shieldCharges);
        n.putString("shieldLabel", shieldLabel);
        n.putInt("roomFalls", roomFalls);
        n.putInt("bestRoom", bestRoom);
        n.putLong("bestTicks", bestTicks);
        return n;
    }

    static PlayerProgress read(NbtCompound n) {
        PlayerProgress p = new PlayerProgress();
        p.room = Math.max(1, Math.min(100, n.getInt("room")));
        p.cpX = n.getDouble("cpX");
        p.cpY = n.getDouble("cpY");
        p.cpZ = n.getDouble("cpZ");
        p.cpYaw = n.getFloat("cpYaw");
        p.personalCheckpoint = n.getBoolean("personal");
        p.hasCheckpoint = n.getBoolean("hasCp");
        p.falls = n.getInt("falls");
        p.ticks = n.getLong("ticks");
        p.finished = n.getBoolean("finished");
        p.rescueCharges = n.getInt("rescue");
        p.shieldCharges = n.getInt("shield");
        p.shieldLabel = n.getString("shieldLabel");
        p.roomFalls = n.getInt("roomFalls");
        p.bestRoom = Math.max(p.room, Math.max(1, n.getInt("bestRoom")));
        p.bestTicks = n.getLong("bestTicks");
        return p;
    }
}
